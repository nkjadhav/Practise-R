anil<-500
ajay<-1000
suresh<-anil+ajay
print(paste("Anil has Rs", anil, "and Ajay has Rs", ajay ))
print(paste("They give their money to Suresh so Suresh has Rs", suresh))


